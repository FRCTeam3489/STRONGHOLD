package org.usfirst.frc.team3489.robot;


import edu.wpi.first.wpilibj.SpeedController;
import edu.wpi.first.wpilibj.AnalogInput;
import edu.wpi.first.wpilibj.CANTalon;
import edu.wpi.first.wpilibj.SampleRobot;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
/**
 * This is a short sample program demonstrating use the basic throttle
 * mode of the new CANTalon.
 */
public class Robot extends SampleRobot {
	Joystick aStick = new Joystick(0);
	CANTalon motor;
    double armSpeed = 0;
  	double Amps = 0;
  public Robot() {
      motor = new CANTalon(29); // Initialize the CanTalonSRX on device 1.
      SmartDashboard.putDouble("Volts", 0);
  }

  /**
    * Runs the motor.
    */
  public void operatorControl() {
	motor.setSafetyEnabled(false);
	SmartDashboard.putBoolean("HighGoal", true);
	SmartDashboard.putBoolean("HighGoal", false); 
	SmartDashboard.putBoolean("LowgGoal",true);
	SmartDashboard.putBoolean("LowGoal", false);
	SmartDashboard.putDouble("Volts", 0);
    while (isOperatorControl() && isEnabled()) {
    	armSpeed =aStick.getY();
    	Amps = motor.getOutputCurrent();
    	
    	//System.out.println(armSpeed);
    	//System.out.println(bDART.get());
    	if(armSpeed < 0.02 && armSpeed > 0){
    		armSpeed = 0;
    	}
    	if(armSpeed > -0.02 && armSpeed < 0) {
    		armSpeed = 0;
    	}
    	//if(armSpeed < 0.02) {
    	//	armSpeed = .50;
    	//}
    	motor.set(armSpeed);
    	SmartDashboard.putDouble("Amps", Amps);
    	SmartDashboard.putDouble("Speed", armSpeed);
    	
    	/* Set the motor's output to half power.
       This takes a number from -1 (100% speed in reverse) to +1 (100% speed
       going forward) */
     

      Timer.delay(0.01);  /* Note that the CANTalon only receives updates every
                           10ms, so updating more quickly would not gain you
                           anything. */
    }
    //motor.disable();
  }
} 
