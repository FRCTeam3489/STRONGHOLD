package org.usfirst.frc.team3489.robot;


import edu.wpi.first.wpilibj.SpeedController;
import edu.wpi.first.wpilibj.AnalogInput;
import edu.wpi.first.wpilibj.CANTalon;
import edu.wpi.first.wpilibj.SampleRobot;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
/**
 * This is a short sample program demonstrating how to use the basic throttle
 * mode of the new CANTalon.
 */
public class Robot extends SampleRobot {
	Joystick aStick = new Joystick(0);
	CANTalon motor;
  DigitalInput bDART  = new DigitalInput(9);
  DigitalInput tDART = new DigitalInput(8);
  double armSpeed = 0;
  boolean toDART = false;
  boolean boDART = false;
  AnalogInput pot = new AnalogInput(1);
  public Robot() {
      motor = new CANTalon(28); // Initialize the CanTalonSRX on device 1.
      SmartDashboard.putDouble("Volts", 0);
  }

  /**
    * Runs the motor.
    */
  public void operatorControl() {
	motor.setSafetyEnabled(false);
	double myPot = 0;
    while (isOperatorControl() && isEnabled()) {
    	armSpeed =aStick.getY();
    	
    	//System.out.println(armSpeed);
    	//System.out.println(bDART.get());
    	if(bDART.get() == false && armSpeed > .02) { //boDART will stop moving down if Limit Switch is false
    	//	armSpeed = 0;
    		boDART = true;
    		System.out.println("Bottom of DART");
    	}
    	if(tDART.get() == false && armSpeed < -.02 ) { //toDART will stop moving up if Limit Switch is false
    	//	armSpeed = 0;
    		toDART = true;
    		System.out.println("Top of DART");
    		
    		 //Negative is extend. Positive is retracting
    	} 
    	if(armSpeed > .02) {toDART = false;}
    	if(armSpeed < -.02) {boDART = false;}
    	
    	if(boDART == true && armSpeed > 0.02) {
    		armSpeed = 0; 
    	} 
    	if(toDART == true && armSpeed < -0.02){
    		armSpeed = 0;
    	}
    	//if(armSpeed < 0.02 || armSpeed > -0.02) { armSpeed = 0.00;}
    	//System.out.println(armSpeed + " " + boDART + " " + toDART);
 
    	
    	//armSpeed = aStick.getY();
    	if(armSpeed < -0.02) { armSpeed = -0.375; } 
    	if(armSpeed > 0.02) { armSpeed = 0.375; } 
    	motor.set(armSpeed);
    	myPot = pot.getVoltage();
    	SmartDashboard.putDouble("Volts", myPot);
    	
    	/* Set the motor's output to half power.
       This takes a number from -1 (100% speed in reverse) to +1 (100% speed
       going forward) */
     

      Timer.delay(0.01);  /* Note that the CANTalon only receives updates every
                           10ms, so updating more quickly would not gain you
                           anything. */
    }
    //motor.disable();
  }
} 
